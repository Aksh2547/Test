package com.contact.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.management.RuntimeErrorException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.contact.dao.UserDao;
import com.contact.model.User;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserDao dao;

	@Override
	public void saveUser(User user) {
		dao.save(user);
		
	}

	@Override
	public List<User> getAllUser() {
		List<User> userList = new ArrayList<User>();
			dao.findAll().forEach(list -> userList.add(list));
			return userList;
		
	}

	@Override
	public void deleteUserById(int id) {
	this. dao.deleteById(id);

	}
	@Override
	public User getuserById(int id) {
		Optional<User> optional = dao.findById(id);

		User user = null;
		if (optional.isPresent()) {
			user = optional.get();
		} else {
			throw new RuntimeErrorException(null, "Product Not Found for id" + id);
		}
		return user;
	}
	
}
