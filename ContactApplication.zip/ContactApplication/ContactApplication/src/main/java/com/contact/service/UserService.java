package com.contact.service;

import java.util.List;

import com.contact.model.User;



public interface UserService {

	void saveUser(User user);

	List<User> getAllUser();

	void deleteUserById(int id);

	User getuserById(int id);

}
