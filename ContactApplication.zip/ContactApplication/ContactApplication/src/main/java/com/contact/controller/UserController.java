package com.contact.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.contact.model.User;
import com.contact.service.UserService;

@Controller
@RequestMapping("/contact")
public class UserController {

	@Autowired
	UserService service;

	@GetMapping("/")
	public String firstPage() {
		return "welcome";
	}

	@GetMapping("/reg")
	public String regPage() {
		return "register";
	}

	@PostMapping("/adduser")
	public String UserDetails(User user) {
		service.saveUser(user);
		return "welcome";
	}

	@RequestMapping("/users")
	public String listUsers(Model model) {
		model.addAttribute("listUsers", service.getAllUser());
		return "user-detail";
	}

	@GetMapping("/deleteUser/{id}")
	public String deleteUser(@PathVariable(value = "id") int id) {

		this.service.deleteUserById(id);
		return "redirect:/contact/users";
	}

	@GetMapping("/showformupdate/{id}")
	public String showFormForUpdate(@PathVariable(value = "id") int id, Model model) {

		User user = service.getuserById(id);
		model.addAttribute("user", user);
		return "update_user";

	}

}
