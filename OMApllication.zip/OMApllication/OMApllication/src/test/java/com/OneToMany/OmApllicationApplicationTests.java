package com.OneToMany;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmApllicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
