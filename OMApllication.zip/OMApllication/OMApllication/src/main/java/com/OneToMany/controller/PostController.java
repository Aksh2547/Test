package com.OneToMany.controller;

import java.security.Principal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.OneToMany.model.Comments;
import com.OneToMany.model.Post;
import com.OneToMany.repository.CommentsRepository;
import com.OneToMany.repository.PostRepository;
import com.OneToMany.service.PostService;

@Controller
//@RequestMapping("/post/")
public class PostController {

	@Autowired
	private PostRepository postRepository;
	private CommentsRepository commentsRepository;
	private PostService postService;

	public PostController(PostRepository postRepository, CommentsRepository commentsRepository) {
		super();
		this.postRepository = postRepository;
		this.commentsRepository = commentsRepository;
	}

	@GetMapping("/")
	public String home() {
		return "welcome";
	}

	@GetMapping("/reg")
	public String regPage() {
		return "register";
	}

	@GetMapping("/posts")
	public String showContacts( Model m) {
		m.addAttribute("title", "Show User Contacts");		
		return "post-detail";
	}

}
