package com.OneToMany.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.OneToMany.model.Post;
import com.OneToMany.repository.CommentsRepository;
import com.OneToMany.repository.PostRepository;

@Service
public class PostService {

	@Autowired
	private PostRepository postRepository;
	private CommentsRepository commentsRepository;

	public PostService(PostRepository postRepository, CommentsRepository commentsRepository) {
		super();
		this.postRepository = postRepository;
		this.commentsRepository = commentsRepository;
	}

}
